<?php
include "include.php";

session_start();

 $query="SELECT * FROM `bus` where id='".$_SESSION['Bus_id']."'" ;
$result= mysqli_query($con,$query);
$row1= mysqli_num_rows($result);
while($row=mysqli_fetch_array($result))
{

$ins="INSERT INTO `booking`(`user`,`Bus_id`,`Origin`,`Destination`,`Total_fare`,`Bank`,`Payment_method`)VALUES('".$_SESSION['user']."','".$_SESSION['Bus_id']."','".$row['Origin']."','".$row['Destination']."','".$_SESSION['Total_fare']."','".$_POST['Bank']."','".$_POST['Payment_method']."')";

$id = $_SESSION['Bus_id'];
mysqli_query($con,$ins) or die(mysql_error());


}

//$user=$_SESSION['user'];
//$Bus_id;




$sel="SELECT * FROM `user` where Username='".$_SESSION['user']."'" ;
$str= mysqli_query($con,$sel);
$rows= mysqli_num_rows($str);


while($row=mysqli_fetch_array($str))
{
$to_email=$row['Email'];
$subject="Online Bus Pass ";
$body="Hello ".$_SESSION['user'].",Your pass booking is done successful...Bus_ID=".$_SESSION['Bus_id']."--You Paid Amount of '".$_SESSION['Total_fare']."' paid by ".$_POST['Bank']."-".$_POST['Payment_method']."";
$headers="From: chimnegayatri@gmail.com";

if(mail($to_email,$subject,$body,$headers))
{}
	$_SESSION['user']=$_POST["Username"];
	
$_SESSION['pay'] = 'Payment successful...Your Bus Pass Booked..Click on Booking History to View';
session_start();

	header('location: generic.php');
echo '<script language="javascript">document.location.href="generic.php"</script>';


}
	
?>