<?php
include "include.php";

session_start();
$req= $_GET['req'];
$id=$_GET['id'];
$del="Delete from `bus` where id='".$_GET['id']."' ";



mysqli_query($con,$del) or die(mysql_error());


echo "Deleted succesfully";
	//$_SESSION['admin']=$_POST["Username"];
	$_SESSION['del'] = 'Cancelled succesfully..Bus ID = ';
	$_SESSION['refund']=$_GET['id'];
	$_SESSION['mesg']='..';
	header('location: view_bus.php');
//echo '<script language="javascript">document.location.href="view_bus.php"</script>';
?>